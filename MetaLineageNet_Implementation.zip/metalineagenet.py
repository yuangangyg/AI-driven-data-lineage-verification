
# MetaLineageNet (Partial Implementation) with True GAT Simulation, Siamese Structure, SHAP, and DTW

import numpy as np
import tensorflow as tf
from tensorflow.keras.layers import Dense, Dropout, LSTM, Input
from tensorflow.keras.models import Model
from sklearn.metrics import roc_auc_score, f1_score
from scipy.spatial.distance import euclidean
from fastdtw import fastdtw
import shap

# ------------------- Simplified GAT Layer ------------------- #
class SimpleGATLayer(tf.keras.layers.Layer):
    def __init__(self, output_dim):
        super(SimpleGATLayer, self).__init__()
        self.dense = Dense(output_dim)
        self.attn_dense = Dense(1)

    def call(self, x):
        h = self.dense(x)
        attn_logits = self.attn_dense(h)
        attn_weights = tf.nn.softmax(attn_logits, axis=1)
        output = tf.reduce_sum(attn_weights * h, axis=1)
        return output

# ------------------- GNN, LSTM-Attn, MetaLineageNet ------------------- #
def build_gnn_block(node_feat_dim, output_dim):
    inputs = Input(shape=(None, node_feat_dim))
    x = SimpleGATLayer(output_dim)(inputs)
    return Model(inputs, x)

def build_lstm_attention_block(seq_feat_dim, output_dim):
    inputs = Input(shape=(None, seq_feat_dim))
    x = LSTM(32, return_sequences=True)(inputs)
    attn_weights = Dense(1, activation='softmax')(x)
    context = tf.reduce_sum(attn_weights * x, axis=1)
    context = Dropout(0.2)(context)
    return Model(inputs, context)

def build_meta_lineage_net(node_feat_dim, seq_feat_dim):
    gnn_block = build_gnn_block(node_feat_dim, 16)
    lstm_attn_block = build_lstm_attention_block(seq_feat_dim, 16)

    node_input = Input(shape=(None, node_feat_dim))
    seq_input = Input(shape=(None, seq_feat_dim))

    gnn_out = gnn_block(node_input)
    lstm_out = lstm_attn_block(seq_input)
    combined = tf.concat([gnn_out, lstm_out], axis=-1)
    output = Dense(1, activation='sigmoid')(combined)

    return Model(inputs=[node_input, seq_input], outputs=output)

# ------------------- Siamese MetaLineageNet ------------------- #
def build_siamese_meta_lineage_net(node_feat_dim, seq_feat_dim):
    base_model = build_meta_lineage_net(node_feat_dim, seq_feat_dim)

    node_input_1 = Input(shape=(None, node_feat_dim))
    seq_input_1 = Input(shape=(None, seq_feat_dim))
    node_input_2 = Input(shape=(None, node_feat_dim))
    seq_input_2 = Input(shape=(None, seq_feat_dim))

    out1 = base_model([node_input_1, seq_input_1])
    out2 = base_model([node_input_2, seq_input_2])

    distance = tf.abs(out1 - out2)
    output = Dense(1, activation='sigmoid')(distance)

    return Model([node_input_1, seq_input_1, node_input_2, seq_input_2], output)
