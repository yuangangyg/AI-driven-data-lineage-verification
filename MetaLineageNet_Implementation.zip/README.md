
# MetaLineageNet (Partial Research Implementation)

This repository provides a partial research-oriented implementation of the proposed MetaLineageNet framework for lineage anomaly detection and drift detection.

## Features Included
- GAT-inspired attention over node features (simulated, no true edge-based GAT)
- LSTM with attention for temporal sequence reasoning
- SHAP explainability integration
- DTW-based drift detection
- Optional Siamese network structure for lineage similarity (contrastive learning)

## Limitations
- No real graph adjacency matrices are used (graph reasoning is approximated)
- Dataset used is synthetic for demonstration
- Full reproducibility of reported manuscript results on real MIMIC-III data is pending

This code is provided to demonstrate key architectural components for peer review and development.
